# Paper & Flow — local Markdown and Mermaid editor

## Start

1. Extract the entire ZIP, keeping the `vendor` folder beside `index.html`.
2. Double-click `index.html` to open it in a modern browser (Safari, Chrome, Edge or Firefox).
3. Start writing. No installation, account, server or internet connection is required.

## Features

- Markdown headings, lists, tables, links, code blocks and blockquotes.
- Mermaid fenced code blocks inside Markdown, plus a standalone Mermaid mode for `.mmd` files.
- Live preview with diagram syntax errors displayed inline.
- Open local text files and download source files; Command/Ctrl+S saves a downloaded copy.
- SVG and PNG export per diagram. Print / PDF uses your browser's print dialog.
- Light/dark editor theme, resizable side-by-side panels, local draft recovery.

To embed a diagram:

````markdown
```mermaid
flowchart TD
    A[Start] --> B{Approved?}
    B -->|Yes| C[Continue]
    B -->|No| D[Stop]
```
````

Choose **Mermaid diagram** mode for files containing only diagram source.

## Saving and privacy

Save source downloads regularly. The app does not overwrite the opened file directly. Browser local storage retains one working draft, which can be unavailable or cleared in private browsing and may vary for file URLs. It is not a backup. New/Open asks before replacing an unsaved draft.

All parsing and diagram rendering run on your device. There are no remote scripts, analytics or document uploads. Remote images and embedded content are intentionally disabled. Markdown HTML is sanitized and Mermaid runs with strict security settings. Clicking an ordinary hyperlink may open its destination in your browser.

Print output includes the current rendered preview. Wait for rendering to finish before printing. Diagrams use a white background for export readability. Very large diagrams may take longer; PNG export is capped at 8192 pixels per dimension. SVG is the best choice for scalable diagrams. Fonts use those available on your computer; no font downloads occur.

## Included libraries

Bundled browser builds: Mermaid 11, Marked 15 and DOMPurify 3. Their license notices are in `vendor/`. Mermaid includes its bundled dependencies. The application source (`index.html`, `style.css`, `app.js`) may be freely used and modified.

## GitLab repository and hosting

See [GITLAB.md](GITLAB.md) for GitLab import/push instructions, Pages deployment, access settings and troubleshooting. The included `.gitlab-ci.yml` validates the source and publishes the editor from the default branch. Local offline use remains available.
