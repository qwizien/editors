#!/bin/sh
# Run from the repository root. Publish only the editor and its vendor assets.
set -eu
for file in index.html app.js style.css vendor/mermaid.min.js vendor/marked.min.js vendor/purify.min.js; do
  if [ ! -s "$file" ]; then
    echo "Missing or empty required file: $file" >&2
    exit 1
  fi
done
mkdir -p public/vendor
cp index.html app.js style.css public/
cp vendor/*.js vendor/LICENSE*.txt public/vendor/
test -s public/index.html
echo 'GitLab Pages files prepared in public/'
