# GitLab repository and Pages setup

This package supports both local use and hosting the same editor on GitLab Pages. It does not connect the editor to the GitLab API: Open and Save still work with files on your computer.

## 1. Create a repository

In GitLab, create a **blank project** named `paper-and-flow`. Leave **Initialize repository with a README** unchecked when following the commands below.

Extract the ZIP and open a terminal in its `Paper-and-Flow` directory. This is the folder containing `index.html`. The supplied `.gitlab-ci.yml` must be at the repository root, alongside `index.html`, not inside another folder.

On macOS, press **Command+Shift+.** in Finder to see the included dotfiles. Using `git add .` includes them automatically.

For a new empty project, run:

```sh
cd /path/to/Paper-and-Flow

git init
git branch -M main
git add .
git commit -m "Add local Markdown and Mermaid editor with GitLab Pages"

# Replace YOUR-NAMESPACE with your GitLab username or group.
# For company GitLab, also replace gitlab.com with your server hostname.
git remote add origin git@gitlab.com:YOUR-NAMESPACE/paper-and-flow.git
git push -u origin main
```

The SSH URL requires an SSH key registered with GitLab. Alternatively, copy the HTTPS clone URL from your project's **Code** menu and use it in `git remote add origin`. Authenticate through Git's credential manager or GitLab's supported token flow; do not put tokens in the repository or editor source.

### Existing repository

Clone your existing repository first, then copy the extracted files into the intended location. If the repository already has `.gitlab-ci.yml`, merge the supplied jobs and stages into that file rather than replacing it. These commands and the supplied pipeline assume the editor lives at the repository root; adapt paths if it belongs in a subdirectory.

Commit and push using your usual branch and merge request workflow. Do not reinitialize the repository or force-push over existing history.

## 2. Enable the pipeline and deploy

Requirements: GitLab.com, or GitLab Self-Managed **17.6+** with GitLab Pages configured; an available CI runner; and permission/compute capacity to run pipelines. The runner must support the `node:22-alpine` container image. For restricted corporate runners, use your approved mirror of that image and add runner tags if required.

The included pipeline does the following:

1. Checks JavaScript syntax and prepares the static site on branch and merge request pipelines.
2. Publishes the editor when changes reach the project's **default branch**. It uses `$CI_DEFAULT_BRANCH`, so the branch need not be named `main`.
3. Copies only `index.html`, `app.js`, `style.css`, and the bundled vendor files into `public/` for publication. Setup instructions, Git metadata and other repository files are not copied.

In your project, open **Build → Pipelines** and wait for `validate` and `publish-pages` to finish. Then open **Deploy → Pages** and use the URL GitLab displays. Do not construct the URL yourself: domains and paths vary by GitLab configuration.

The app uses relative asset URLs, so it can run under a project subpath as well as a dedicated Pages domain. The build installs no npm packages and fetches no rendering libraries; all editor dependencies are bundled. The CI runner may still need network access to pull its container image and clone the repository.

## 3. Choose who can access the hosted editor

Check the project's Pages access controls before sharing its URL. Repository visibility alone is not a substitute for checking the Pages audience. If your installation supports Pages access control, restrict access to the intended project members or authenticated users as appropriate. On Self-Managed GitLab, your administrator may need to enable it.

Editing stays in the browser. This static site has no document-upload service, GitLab token field or automatic repository commits. Source downloads must be committed through Git or GitLab separately. The hosted editor's local draft is stored per browser origin and is separate from a file opened via `file://`; save your source before switching between them.

## 4. Subsequent updates

```sh
git add .
git commit -m "Update editor"
git push
```

Changes on the default branch trigger a new deployment. Other branches and merge requests are checked but do not replace the published editor.

For repository storage and local use only, omit `.gitlab-ci.yml` before the first push. The editor still opens by double-clicking `index.html`.

## Local checks

With Node.js installed:

```sh
node --check app.js
sh scripts/build-pages.sh
```

To preview the exact Pages output using Python 3:

```sh
python3 -m http.server 8000 --bind 127.0.0.1 --directory public
```

Visit http://127.0.0.1:8000 and stop the server with Ctrl+C. You can still open the original `index.html` directly without Node.js or Python.

## Troubleshooting

- **Pipeline pending:** enable an appropriate runner and check its tags and available compute capacity.
- **Image cannot be pulled:** use a permitted container registry/mirror.
- **Pages keyword rejected:** confirm your Self-Managed GitLab version supports `pages: true` (17.6+), or ask the administrator for the instance's supported Pages configuration. Validate the YAML in GitLab's Pipeline Editor / CI Lint.
- **No deployment:** verify the commit is on the project's default branch and Pages is enabled by your administrator.
- **404 or missing styles/scripts:** use the URL shown under Deploy → Pages and check that `index.html` and `vendor/` are at the root of the published artifact.
- **Protected branch rejects push:** use a feature branch and merge request under your project's policy.

The pipeline has been checked locally for YAML structure and static build output; it has not been executed on your GitLab instance. Browser rendering/export verification remains as described in the original delivery.

## Official references

- [GitLab Pages from scratch](https://docs.gitlab.com/user/project/pages/getting_started/pages_from_scratch/)
- [GitLab CI/CD YAML reference](https://docs.gitlab.com/ci/yaml/)
- [GitLab Pages access control](https://docs.gitlab.com/user/project/pages/pages_access_control/)
